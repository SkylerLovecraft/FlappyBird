#!/bin/bash
set -e -x
clear
clear
clear
javac Game.java View.java Controller.java Model.java Bird.java Background.java Hand.java 
